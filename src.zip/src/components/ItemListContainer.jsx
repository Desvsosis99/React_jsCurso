import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getProductsByCategory } from '../data/mockData';

function ItemListContainer() {
  const { categoryId } = useParams();
  const [items, setItems] = useState([]);

  useEffect(() => {
    const products = getProductsByCategory(categoryId);
    setItems(products);
  }, [categoryId]);

  return (
    <div>
      <h1>Productos</h1>
      <ul>
        {items.map(item => (
          <li key={item.id}>
            <h2>{item.name}</h2>
            <p>{item.description}</p>
            <img src={item.imageUrl} alt={item.name} />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ItemListContainer;
